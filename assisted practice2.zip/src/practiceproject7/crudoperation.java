package practiceproject7;
import java.io.*;
public class crudoperation {

	public static void main(String[] args) {
		try
		{
			
            File file = new File("sample.txt"); 
            file.createNewFile();
            System.out.println("File created successfully");
            
            FileWriter writer = new FileWriter(file);
            writer.write("Hello, this is some content in the file.");
            writer.close();
            System.out.println("Content written to the file.");
            
            FileReader reader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            System.out.println("Reading from the file:");
            while ((line = bufferedReader.readLine()) != null)
            {
                System.out.println(line);
            }
            reader.close();

           
            FileWriter updater = new FileWriter(file, true); 
            updater.write("\nAppending more content to the file.");
            updater.close();
            System.out.println("Content updated in the file.");

            
            FileReader reader2 = new FileReader(file);
            BufferedReader bufferedReader2 = new BufferedReader(reader2);
            String line2;
            System.out.println("Reading from the file after update:");
            
            while ((line2 = bufferedReader2.readLine()) != null) 
            {
                System.out.println(line2);
            }
            reader2.close();

            
            if (file.delete())
            {
                System.out.println("File deleted successfully.");
            } 
            else 
            {
                System.out.println("Failed to delete the file.");
            }
        } 
		catch (IOException e) 
		{
            e.printStackTrace();
        }
		
	}
	


	}


