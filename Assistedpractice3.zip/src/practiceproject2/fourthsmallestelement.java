package practiceproject2;

public class fourthsmallestelement {
		public void sortArr(int arr[])
		{
		int size = arr.length;
		for(int i = 0; i < size; i++)
		{
		int temp = i;
		for(int j = i + 1; j < size; j++)
		{
		if(arr[temp] > arr[j])
		{
		temp = j;
		}
		}
		if(temp != i)
		{
		int t = arr[i];
		arr[i] = arr[temp];
		arr[temp] = t;
		}
		}
		}	
		public int findFourthSmallest(int arr[], int k)
		{
		return arr[k - 1];
		}
		public static void main(String argvs[])
		{
		fourthsmallestelement obj = new fourthsmallestelement();

		int arr1[] = {55,84,64,28,91,22,13,41,5,62,34};
		int size = arr1.length;
		int k = 4;
		System.out.println("array: ");
		for(int i = 0; i < size; i++)
		{
		System.out.print(arr1[i] +" ");
		}
		int element = obj.findFourthSmallest(arr1, k);
		System.out.println();
		System.out.println(" The " + k + " th smallest element in the array	is:" + element);


	}

}
